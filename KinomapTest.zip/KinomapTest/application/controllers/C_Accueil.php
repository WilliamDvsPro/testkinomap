<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class C_Accueil extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{
		$data['titre'] = 'Test pour Kinomap';
		$this->load->helper("url");

		#Choix de la page à stocker dans la variable $page
		$page = $this->load->view('V_accueil', $data, true);

		#Charger la vue template et y intégrer la variable $page
		$this->load->view('commun/V_template', array('contenu' => $page));
	}
}
