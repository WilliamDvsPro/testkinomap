<!DOCTYPE html>

<html lang="en">
    <head>
        <title><?php echo $titre ?></title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="<?php echo base_url('assets/css/designTemplate.css')?>" rel="stylesheet">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

    </head>
    <header>
  
    </header>
    <body>
        <div id='contenu'>
            <?php echo $contenu; ?>
        </div>
    </body>
    <footer>
    </footer>
</html>