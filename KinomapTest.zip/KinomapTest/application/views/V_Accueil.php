<html>
    <div>
    <h1>Voici mon carrousel</h1>
            <p>Celui-ci a été créé avec le langage HTML, CSS et JavaScript.</p>
    </div>
    <!-- DEBUT DU CAROUSSEL -->
    <div class="slider">
        <div class="slider-track">

            <!-- DEBUT DES IMAGES -->
            <div class="slide">
            </div>
            <!-- FIN DES IMAGES -->

        </div>

    </div>
    <!-- FIN DU CAROUSSEL -->
    
    <script type="" src=<?php echo base_url("assets/js/carrousel.js") ?>></script>
    
</html>