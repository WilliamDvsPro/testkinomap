this.carrousel = document.querySelector('.slider-track');
const request = new XMLHttpRequest();
request.open("GET","http://localhost/KilomapAPI/test");
request.send();
request.onload = () => {
    if(request.status === 200){
        console.log(JSON.parse(request.response));
        var dataAPI = JSON.parse(request.responseText);
        //RecupererImages(dataAPI);
        ImgWeigth(dataAPI);
    }else{
        console.log(`La requête n'a pas pu être envoyée : ${request.status}`);
    }
}

//Récupération des images dans l'ordre du tableau de l'API (désodre)
function RecupererImages(dataAPI){
{       
        dataAPI.forEach(images=>{
            const item = document.createElement('div');
            item.classList.add('slide');
            item.innerHTML = 
            `

                <img src="${images.image}">

            `;
            this.carrousel.appendChild(item);
            console.log(this.carrousel.appendChild(item));
            console.log(images.weight);
        });
    }
};
//Fonction pour afficher les images en fonction de leur poids
// AFFICHAGE DE LOGOS DE POIDS 5 : x4
// AFFICHAGE DE LOGOS DE POIDS 3 : x3
// AFFICHAGE DE LOGOS DE POIDS 2 : x2
// AFFICHAGE DE LOGOS DE POIDS 1 : x1
function ImgWeigth(dataAPI){
    for(var i = 0; i < 1; i++){


            //AFFICHAGE 1 (POIDS : 5,3,2,1)
            dataAPI.forEach(imgWeigth=>{


                    //RECUPERATION DES IMAGES DE POIDS 1
                    if(imgWeigth.weight===1){
                        
                        var imgPoids1 = imgWeigth.image;
                        console.log(imgPoids1);  
                        
                        const item = document.createElement('div');
                            item.classList.add('slide');
                            item.innerHTML = 
                            `
                                <img src="${imgPoids1}">
                            `;
                            this.carrousel.appendChild(item);
                            console.log(this.carrousel.appendChild(item));
                        
                        
                    };

                    //RECUPERATION DES IMAGES DE POIDS 2
                    if(imgWeigth.weight===2){
                        
                        var imgPoids2 = imgWeigth.image;
                        console.log(imgPoids2);  
                        
                        const item = document.createElement('div');
                            item.classList.add('slide');
                            item.innerHTML = 
                            `
                                <img src="${imgPoids2}">
                            `;
                            this.carrousel.appendChild(item);
                            console.log(this.carrousel.appendChild(item));

                    };

                    //RECUPERATION DES IMAGES DE POIDS 3
                    if(imgWeigth.weight===3){
                        
                        var imgPoids3 = imgWeigth.image;
                        console.log(imgPoids3);  
                        
                        const item = document.createElement('div');
                            item.classList.add('slide');
                            item.innerHTML = 
                            `
                                <img src="${imgPoids3}">
                            `;
                            this.carrousel.appendChild(item);
                            console.log(this.carrousel.appendChild(item));
                        
                    };

                    //RECUPERATION DES IMAGES DE POIDS 5
                    if(imgWeigth.weight===5){
                            
                        var imgPoids5 = imgWeigth.image;
                        console.log(imgPoids5);  
                        
                        const item = document.createElement('div');
                            item.classList.add('slide');
                            item.innerHTML = 
                            `
                                <img src="${imgPoids5}">
                            `;
                            this.carrousel.appendChild(item);
                            console.log(this.carrousel.appendChild(item));
                        
                        };
            })

            //AFFICHAGE 2 (POIDS : 5,3,2)
            dataAPI.forEach(imgWeigth=>{
                    //RECUPERATION DES IMAGES DE POIDS 2
                    if(imgWeigth.weight===2){
                        
                        var imgPoids2 = imgWeigth.image;
                        console.log(imgPoids2);  
                        
                        const item = document.createElement('div');
                            item.classList.add('slide');
                            item.innerHTML = 
                            `
                                <img src="${imgPoids2}">
                            `;
                            this.carrousel.appendChild(item);
                            console.log(this.carrousel.appendChild(item));
                        
                    //RECUPERATION DES IMAGES DE POIDS 3
                    if(imgWeigth.weight===3){
                        
                        var imgPoids3 = imgWeigth.image;
                        console.log(imgPoids3);  
                        
                        const item = document.createElement('div');
                            item.classList.add('slide');
                            item.innerHTML = 
                            `
                                <img src="${imgPoids3}">
                            `;
                            this.carrousel.appendChild(item);
                            console.log(this.carrousel.appendChild(item));
                        
                    };


                    };

                    //RECUPERATION DES IMAGES DE POIDS 5
                    if(imgWeigth.weight===5){
                            
                        var imgPoids5 = imgWeigth.image;
                        console.log(imgPoids5);  
                        
                        const item = document.createElement('div');
                            item.classList.add('slide');
                            item.innerHTML = 
                            `
                                <img src="${imgPoids5}">
                            `;
                            this.carrousel.appendChild(item);
                            console.log(this.carrousel.appendChild(item));
                        
                        };

            })
            //AFFICHAGE 2=3 (POIDS : 5,3)
            dataAPI.forEach(imgWeigth=>{

                    //RECUPERATION DES IMAGES DE POIDS 3
                    if(imgWeigth.weight===3){
                        
                        var imgPoids3 = imgWeigth.image;
                        console.log(imgPoids3);  
                        
                        const item = document.createElement('div');
                            item.classList.add('slide');
                            item.innerHTML = 
                            `
                                <img src="${imgPoids3}">
                            `;
                            this.carrousel.appendChild(item);
                            console.log(this.carrousel.appendChild(item));
                        
                    };

                    //RECUPERATION DES IMAGES DE POIDS 5
                    if(imgWeigth.weight===5){
                            
                        var imgPoids5 = imgWeigth.image;
                        console.log(imgPoids5);  
                        
                        const item = document.createElement('div');
                            item.classList.add('slide');
                            item.innerHTML = 
                            `
                                <img src="${imgPoids5}">
                            `;
                            this.carrousel.appendChild(item);
                            console.log(this.carrousel.appendChild(item));
                        
                        };
            })
            //AFFICHAGE 2=3 (POIDS : 5)
            dataAPI.forEach(imgWeigth=>{

                //RECUPERATION DES IMAGES DE POIDS 5
                if(imgWeigth.weight===5){
                        
                    var imgPoids5 = imgWeigth.image;
                    console.log(imgPoids5);  
                    
                    const item = document.createElement('div');
                        item.classList.add('slide');
                        item.innerHTML = 
                        `
                            <img src="${imgPoids5}">
                        `;
                        this.carrousel.appendChild(item);
                        console.log(this.carrousel.appendChild(item));
                    
                    };
        })
 
    }
}




/*
$.ajax({
    url:"http://localhost/KilomapAPI/test",
    dataType:"json",
    success: function(data){
        console.log("REUSSI",data);
    },
    error: function(err){
        console.log("ERREUR",err)
    },
});

var parseJSON = function(data){

        $(data).each(function(i)
        {
            
        });
    }

var createHTML = function(element){
    for(var i = 0; i < element.results.length; i++){
 
        var logo = $("<p>")(HTMLElement(element).results[i].text);
        $('#TEST').append(logo);
         
    };
}*/

